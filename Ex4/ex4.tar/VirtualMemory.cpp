/**
 * @file: MapReduceFramework.cpp
 * @authors: Muaz.Abdeen (300575297)
 *           almogco (207005950)
 * @brief:
 */

// ------------------------------ includes ------------------------------------------

#include "VirtualMemory.h"
#include "PhysicalMemory.h"

//#include <cstdio>
//#include <bitset>

// ------------------------------ macros & constants --------------------------------

#define SUCCESS 1
#define FAILURE 0

// ------------------------------ GLOBAL VARIABLES -----------------------------------
				/** IMPORTANT : DO NOT USE GLOBAL VARIABLES **/
// ------------------------------ NON API FUNCTIONS ----------------------------------

word_t max(word_t num1, word_t num2) { return num1 > num2 ? num1 : num2; }
word_t min(word_t num1, word_t num2) { return num1 < num2 ? num1 : num2; }
void clearTable(uint64_t frameIndex);
int mapPageToFrame(const uint64_t &pageIDX, uint64_t &frameIDX);
int getFrameIDX(word_t &frameIDX, word_t &lastAddedFrameIDX);
word_t getEmptyFrame(word_t rootFrameIDX, word_t layer, const word_t &lastAddedFrameIDX);
word_t getUnusedFrame(word_t rootFrameIDX, word_t layer);
uint64_t getEvictedFrameIDX(word_t rootFrameIDX, word_t layer,
							uint64_t pageIndex, uint64_t &evictedPageIDX,
							uint64_t &evictedFrameIDX,
							uint32_t &maxPathWeight, uint32_t curPathWeight);
int evictFrame(uint64_t &frameIDX);
void unlinkFrame(word_t rootFrameIDX, word_t layer, const word_t &frameToUnlink);

// -----------------------------------------------------------------------------------

//void printRAM() {
//	word_t value;
//	for (uint64_t i = 0; i < RAM_SIZE; ++i) {
//		if (i % PAGE_SIZE == 0) {
//			printf("FRAME ");
//			std::bitset<PHYSICAL_ADDRESS_WIDTH - OFFSET_WIDTH> f(i);
//			printf("%s : ", f.to_string().c_str());
//		}
//		PMread(i, &value);
//		printf("   %d   ", value);
//		if (i % PAGE_SIZE == PAGE_SIZE-1) { printf("\n"); }
//	}
//}


/**
 * @brief clears the page table pointed by the given frameIndex,
 * 		  that is, to assign 0 to all of the frame words.
 * @param frameIndex index of the frame pointing to the table.
 */
void clearTable(uint64_t frameIndex) {
	for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
		PMwrite(frameIndex * PAGE_SIZE + i, 0);
	}
}

/**
 * @brief
 * @param rootFrameIDX
 * @param layer
 * @param lastAddedFrameIDX
 * @return
 */
word_t getEmptyFrame(word_t rootFrameIDX, word_t layer, const word_t &lastAddedFrameIDX) {
	word_t currentFrameIDX;
	word_t minEmptyFrameIDX = NUM_FRAMES;
	int emptyRows = 0;
	for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
		PMread(rootFrameIDX * PAGE_SIZE + i, &currentFrameIDX);
		if (currentFrameIDX > 0 && layer < TABLES_DEPTH - 1) {
			word_t emptyIndex = getEmptyFrame(currentFrameIDX, layer+1, lastAddedFrameIDX);
			minEmptyFrameIDX = min(minEmptyFrameIDX, emptyIndex);
		} else if (currentFrameIDX == 0) { emptyRows++; }
		// the empty frame is not the parent
		if (emptyRows == PAGE_SIZE && rootFrameIDX != lastAddedFrameIDX) {
			minEmptyFrameIDX = rootFrameIDX;
		}
	}
	return minEmptyFrameIDX;
}

/**
 * @brief
 * @param rootFrameIDX
 * @param layer
 * @return
 */
word_t getUnusedFrame(word_t rootFrameIDX, word_t layer) {
	word_t currentFrameIDX;
	word_t maxFrameIDX = 0;
	for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
		PMread(rootFrameIDX * PAGE_SIZE + i, &currentFrameIDX);
		maxFrameIDX = max(currentFrameIDX, maxFrameIDX);
		if (currentFrameIDX > 0 && layer < TABLES_DEPTH - 1) {
			maxFrameIDX = max(maxFrameIDX, getUnusedFrame(currentFrameIDX, layer+1) - 1);
		}
	}
	return maxFrameIDX + 1;
}

uint64_t getEvictedFrameIDX(word_t rootFrameIDX, word_t layer,
						   uint64_t pageIndex, uint64_t &evictedPageIDX,
						   uint64_t &evictedFrameIDX,
						   uint32_t &maxPathWeight, uint32_t curPathWeight) {
	word_t currentFrameIDX = rootFrameIDX;
	if (layer == TABLES_DEPTH) {
		curPathWeight += pageIndex % 2 ? WEIGHT_ODD : WEIGHT_EVEN;
		if (curPathWeight > maxPathWeight) {
			maxPathWeight = curPathWeight;
			evictedFrameIDX = currentFrameIDX;
			evictedPageIDX = pageIndex;
		}
		return evictedFrameIDX;
	}

	for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
		PMread(rootFrameIDX * PAGE_SIZE + i, &currentFrameIDX);
		if (currentFrameIDX != 0) {
			evictedFrameIDX = getEvictedFrameIDX(currentFrameIDX, layer + 1,
							pageIndex + (i << (OFFSET_WIDTH * (TABLES_DEPTH - layer - 1))),
							evictedPageIDX, evictedFrameIDX, maxPathWeight,
							curPathWeight + (currentFrameIDX % 2 ? WEIGHT_ODD : WEIGHT_EVEN));
		}
	}
	// if evictedFrameIDX is 0, that is can not evict any frame
	return evictedFrameIDX;
}


int evictFrame(uint64_t &frameIDX) {
	uint32_t maxPathWeight = WEIGHT_EVEN;
	uint64_t evictedPageIDX;
	frameIDX = getEvictedFrameIDX(0, 0,
							   0, evictedPageIDX, frameIDX,
							   maxPathWeight, WEIGHT_EVEN);
	if (frameIDX > 0) {
		PMevict(frameIDX, evictedPageIDX);
		return SUCCESS;
	}
	return FAILURE;
}

/**
 * @brief
 * @param rootFrameIDX
 * @param layer
 * @param frameToUnlink
 */
void unlinkFrame(word_t rootFrameIDX, word_t layer, const word_t &frameToUnlink) {
	word_t frameIndex;
	for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
		PMread(rootFrameIDX * PAGE_SIZE + i, &frameIndex);
		if (frameIndex == frameToUnlink) {
			PMwrite(rootFrameIDX * PAGE_SIZE + i, 0);
			return;
		}
		if (frameIndex > 0 && layer < TABLES_DEPTH - 1) {
			unlinkFrame(frameIndex, layer+1, frameToUnlink);
		}
	}
}

/**
 * @brief
 * @param frameIDX
 * @param lastAddedFrameIDX
 * @return
 */
int getFrameIDX(word_t &frameIDX, word_t &lastAddedFrameIDX) {
	/* (1) get an empty table, and remove the reference to this table from its parent. */
	frameIDX = getEmptyFrame(0, 0, lastAddedFrameIDX);
	if (frameIDX > 0 && frameIDX < NUM_FRAMES) {
		unlinkFrame(0,0, frameIDX);
		return SUCCESS;
	}
	/* (2) get an unused frame. */
	frameIDX = getUnusedFrame(0, 0);
	if (frameIDX > 0 && frameIDX < NUM_FRAMES) { return SUCCESS; }

	/* (3) If all frames are already used, then a page must be swapped out from some frame
	 * 	   in order to replace it with the relevant page (a table or actual page). */
	uint64_t evictedFrame = 0;
	if (evictFrame(evictedFrame)) {
		frameIDX = evictedFrame;
		unlinkFrame(0,0, frameIDX);
		return SUCCESS;
	}
	return FAILURE;
}

/**
 * @brief
 * @param pageIDX
 * @param frameIDX
 * @return
 */
int mapPageToFrame(const uint64_t &pageIDX, uint64_t &frameIDX) {
	word_t curTableAddr = 0;
	word_t nextTableAddr;
	for (auto layer = 0; layer < TABLES_DEPTH; ++layer) {
		word_t offset = (pageIDX >> (OFFSET_WIDTH * (TABLES_DEPTH - layer - 1))) % PAGE_SIZE;
		PMread(curTableAddr * PAGE_SIZE + offset, &nextTableAddr);
		if (nextTableAddr == 0) {
			// (1) Find an unused frame or evict a page from some frame.
			if (!getFrameIDX(nextTableAddr, curTableAddr)) { return FAILURE; }
			// (2) Write 0 in all of its contents (only necessary in tables)
			if (layer < TABLES_DEPTH - 1) { clearTable(nextTableAddr); }
			// (3) Restore the page we are looking for to frame (only necessary in actual pages)
			else {
//				clearTable(nextTableAddr);
				PMrestore(nextTableAddr, pageIDX);
			}
			// (4) link the table to its parents.
			PMwrite(curTableAddr * PAGE_SIZE + offset, nextTableAddr);
		}
		curTableAddr = nextTableAddr;
	}
	frameIDX = (uint64_t) curTableAddr;
	return SUCCESS;
}


// ================================================================================== //
// ============================== LIBRARY API ======================================= //
// ================================================================================== //

/**
 * @brief Initialize the virtual memory
 * 		  According to the given design, VMInitialize() only has to clear frame 0.
 *
 * 		  			## ALREADY IMPLEMENTED FOR US ##
 */
void VMinitialize() {
	if (NUM_FRAMES != 0) {
		clearTable(0);
	}
}

/**
 * @brief reads a word from the given virtual address and puts its content in *value.
 * @param virtualAddress virtualAddress to read from.
 * @param value value to be read.
 * @return returns 1 on success, or 0 on failure (if the address cannot be mapped to
 * 		   a physical address for any reason).
 */
int VMread(uint64_t virtualAddress, word_t* value) {
	// bad virtualAddress
	if (virtualAddress < 0 || virtualAddress >= VIRTUAL_MEMORY_SIZE) { return FAILURE; }
	// I. separate page index from offset
	uint64_t pageIDX = virtualAddress / PAGE_SIZE;
	uint64_t offset = virtualAddress % PAGE_SIZE;

	// II. map pageIDX to frameIDX in the RAM
	uint64_t frameIDX;
	if (!mapPageToFrame(pageIDX, frameIDX)) { return FAILURE; }

	// III. generate physicalAddress
	uint64_t physicalAddress = frameIDX * PAGE_SIZE + offset;

	// VI. read from RAM to *value
	PMread(physicalAddress, value);

    return SUCCESS;
}

/**
 * @brief writes a word to the given virtual address
 * @param virtualAddress virtualAddress to write to.
 * @param value value to be written.
 * @return returns 1 on success, or 0 on failure (if the address cannot be mapped to
 * 		   a physical address for any reason).
 */
int VMwrite(uint64_t virtualAddress, word_t value) {
	// bad virtualAddress
	if (virtualAddress < 0 || virtualAddress >= VIRTUAL_MEMORY_SIZE) { return FAILURE; }
	// I. separate page index from offset
	uint64_t pageIDX = virtualAddress / PAGE_SIZE;
	uint64_t offset = virtualAddress % PAGE_SIZE;

//	printf("Virtual address = ");
//	for (auto layer = 0; layer < TABLES_DEPTH; ++layer) {
//		word_t tableOffSet = (pageIDX >> (OFFSET_WIDTH * (TABLES_DEPTH - layer - 1))) % PAGE_SIZE;
//		std::bitset<OFFSET_WIDTH>bitStr (tableOffSet);
//		printf("%s ", bitStr.to_string().c_str());
//	}
//	std::bitset<OFFSET_WIDTH>bit00 (offset);
//	printf("[%s]\n", bit00.to_string().c_str());

	// II. map pageIDX to frameIDX in the RAM
	uint64_t frameIDX = 0;
	if (!mapPageToFrame(pageIDX, frameIDX)) { return FAILURE; }
//	printf("page %llu mapped to frame %llu\n", pageIDX, frameIDX);

	// III. generate physicalAddress
	uint64_t physicalAddress = frameIDX * PAGE_SIZE + offset;

	// VI. write *value to RAM
	PMwrite(physicalAddress, value);

//	std::bitset<PHYSICAL_ADDRESS_WIDTH - OFFSET_WIDTH> b5(physicalAddress / PAGE_SIZE);
//	std::bitset<OFFSET_WIDTH> b6(physicalAddress % PAGE_SIZE);
//	printf("Physical address = %s [%s]\n", b5.to_string().c_str(), b6.to_string().c_str());
//
//	printf(" == writing FINISH ==\n");

    return SUCCESS;
}
